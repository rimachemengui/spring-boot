package tn.spring.springboot.entities;

import javax.persistence.*;

@Entity
public class Equipe {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="idEquipe")
    private int idEquipe;
    String nomEquipe;
    Niveau niveau;
}
