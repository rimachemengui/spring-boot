package tn.spring.springboot.entities;

import javax.persistence.*;

@Entity
public class Departement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="idDepart")
    private int idDepart;
    String nomDepart;
}
