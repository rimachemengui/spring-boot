package tn.spring.springboot.entities;

public enum Specialite {
    IA,RESEAUX,CLOUD,SECURITE
}
