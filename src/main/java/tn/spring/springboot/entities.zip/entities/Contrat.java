package tn.spring.springboot.entities;


import javax.persistence.*;
import java.util.Date;
@Entity
public class Contrat {
    @Id
    @GeneratedValue  (strategy = GenerationType.IDENTITY)
    @Column (name="idContrat")
    private int idContrat;
    Date dateDebutContrat;
    Date dateFinContrat;
    Specialite specialite;
    Boolean archive;
}
