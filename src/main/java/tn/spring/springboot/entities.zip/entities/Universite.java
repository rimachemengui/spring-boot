package tn.spring.springboot.entities;

import javax.persistence.*;

@Entity
public class Universite {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="idUniv")
    private int idUniv;
    String nomUniv;
}
