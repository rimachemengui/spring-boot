package tn.spring.springboot.entities;

import javax.persistence.*;

@Entity
public class Etudiant {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="idEtudiant")
    private int idEtudiant;
    String prenomE;
    String nomE;
    Option option;

}
