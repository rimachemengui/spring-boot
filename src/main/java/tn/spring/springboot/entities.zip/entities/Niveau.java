package tn.spring.springboot.entities;

public enum Niveau {
JUNIOR,SENIOR,EXPERT
}
